package junit;

public class Calculation {
    public int add(int a, int b){
        int result = a + b;
        return result;
    }
}
