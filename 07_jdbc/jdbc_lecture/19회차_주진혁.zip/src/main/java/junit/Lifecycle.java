package junit;

// import static org.junit.jupiter.api.Assertions.*;


public class Lifecycle {
}
