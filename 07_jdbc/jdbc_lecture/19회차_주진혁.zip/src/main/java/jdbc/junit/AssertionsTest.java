package jdbc.junit;

public class AssertionsTest {
}
